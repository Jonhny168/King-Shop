let cart = 0;
function addToCart(name, price) {
  cart++;
  document.getElementById('cart-count').innerText = cart;
  alert(`Added ${name} to cart.`);
}

async function loadProducts() {
  const res = await fetch('/api/products');
  const data = await res.json();
  const container = document.getElementById('products');

  data.forEach(p => {
    const div = document.createElement('div');
    div.className = 'product-card';
    div.innerHTML = `
      <img src="${p.image}" alt="${p.name}">
      <h3>${p.name}</h3>
      <p>$${p.price}</p>
      <button onclick="addToCart('${p.name}', ${p.price})">Add to Cart</button>
    `;
    container.appendChild(div);
  });
}

loadProducts();
const express = require('express');
const fs = require('fs-extra');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));
app.use('/admin', express.static('admin'));
app.use('/images', express.static('images'));

const DB_FILE = 'database.json';

app.get('/api/products', async (req, res) => {
  const data = await fs.readJSON(DB_FILE);
  res.json(data.products);
});

app.post('/api/products', async (req, res) => {
  const data = await fs.readJSON(DB_FILE);
  const newProduct = req.body;
  newProduct.id = Date.now();
  data.products.push(newProduct);
  await fs.writeJSON(DB_FILE, data, { spaces: 2 });
  res.json({ success: true });
});

app.delete('/api/products/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const data = await fs.readJSON(DB_FILE);
  data.products = data.products.filter(p => p.id !== id);
  await fs.writeJSON(DB_FILE, data, { spaces: 2 });
  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`King Shop server running`);
});